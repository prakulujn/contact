Submitted By Prashant kulkarni.


** This project has been tested on Chrome and FireFox. (Since IE does not support backtick `` need to install Babel
 to run this project). Chrome Screen shots have been attached here with.

********* Imporatant****************

Contact.txt file should save as contact.js file before run this project


1. This assignement has been developed in Core Javascript
2. Internet should be on  to run this project because button CSS included from external source.
3. hOW TO RUN PROJECT

To run this project open index.html file in chrome.
